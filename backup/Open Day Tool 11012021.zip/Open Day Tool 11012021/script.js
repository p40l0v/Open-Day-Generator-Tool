const modContainer = document.querySelector('#modcontainer')
let elements = document.querySelectorAll('.element')
let images = document.querySelectorAll("img");
let texts = document.querySelectorAll('h1')
let fontSizes = []
texts.forEach((text) => {
    var style = window.getComputedStyle(text, null).getPropertyValue('font-size');
    var fontSize = parseFloat(style); 
    fontSizes.push(fontSize)
});
let modules = []

const nameForm = document.querySelector('form#name')
const nameButton = document.querySelector("#name-button");
const nameField = document.querySelector("#name-field");
const nameElement = document.querySelector("h1#name")


const timeForm = document.querySelector('form#time')
const timeStartInput = document.querySelector("#time-start-input");
const timeEndInput = document.querySelector("#time-end-input");
const timeStartElement = document.querySelector("#time-start")
const timeEndElement = document.querySelector("#time-end")

const eventForm = document.querySelector('form#event')
const eventSelect = document.querySelector('select#event')

const quantForm = document.querySelector('form#quantity-slider')
const quantInput = document.querySelector('#quantity-range.slider')
const quantNumber = document.querySelector('#quantity-number')

/* const sizeForm = document.querySelector('form#size-slider')
const sizeInput = document.querySelector('#size-range.slider')
const sizeNumber = document.querySelector('#size-number') */

const formatForm = document.querySelector('form#formats')
const widthInput = document.querySelector('input#width')
const heightInput = document.querySelector('input#height')

const randomiseButton = document.querySelector('button#randomise')

let quantity = document.querySelector("#quantity-range").value;
let event = eventSelect.value

// creating modules
function moduleCreator(quantity, event) {
    for (let i = 0; i < quantity; i++) {
        let mod = document.createElement('li');
        mod.className = 'module'
        mod.innerHTML = `<figure> <img src='${event}.jpg'> </figure>`;
        modContainer.appendChild(mod);
        modules.push(mod)

        randomiser(quantity)
    }
}

//randomise modules
function randomiser(quantity) {
    for (let e = 0; e < elements.length; e++) {
    modContainer.insertBefore(elements[e], modContainer.childNodes[Math.floor(Math.random()*quantity)])
    }
}

nameForm.addEventListener('submit', () => {
    console.log("name submitted")
    addField(nameField, nameElement);
    nameField.value= ""
})

timeForm.addEventListener('change', () => {
    addField(timeStartInput, timeStartElement);
    addField(timeEndInput, timeEndElement);
    console.log("timesubmit")
})

function addField(field, element) {
    console.log(field.value)
    element.innerHTML = field.value;
}

eventSelect.addEventListener('change', () => {
    console.log('submitted', eventSelect.value)

    removeElementsByClass('module')
    moduleCreator(quantInput.value, eventSelect.value)
})

quantInput.addEventListener('change', () => {
    quantNumber.innerHTML = quantInput.value
    removeElementsByClass('module')
    moduleCreator(quantInput.value, eventSelect.value)    
    if (eventSelect.value == 'qa') {
    document.documentElement.style.setProperty('--text-color', '#000000');
    } else if (eventSelect.value == 'lecture') {
    document.documentElement.style.setProperty('--text-color', '#0000ff');
    } else if (eventSelect.value == 'other') {
    document.documentElement.style.setProperty('--text-color', '#ffff00');
    }
})

formatForm.addEventListener('change', () => {
    changeSize(widthInput.value, heightInput.value)
})

function changeSize(widthValue, heightValue) {
    removeElementsByClass('module')
    widthRatio = widthValue / heightValue
    modContainer.style.height = `100vh`
    modContainer.style.width = `${widthRatio*100}vh`
    modContainer.style.gridTemplateColumns = `repeat(auto-fit, minmax(${2.5*widthRatio}%, 1fr))`
    modContainer.style.gridTemplateRows = `repeat(auto-fit, minmax(${2.5*widthRatio}%, 1fr))`
    texts.forEach((text, i) => {
        console.log(fontSizes[i])
        text.style.fontSize = `${fontSizes[i]/widthRatio}px`
    });
    moduleCreator(quantInput.value, eventSelect.value)
}

/* sizeInput.addEventListener('change', () => {
    sizeValue = +sizeInput.value + +50
    sizeNumber.innerHTML = sizeInput.value

    //modContainer grid needs to be changed with minmax values instead of the bottom

    for(let m = 0; m < modules.length; m++) {
    modules[m].style.width = `${sizeValue}%`
    modules[m].style.height = `${sizeValue}%`
    }
    for(let e = 0; e < elements.length; e++) {
    elements[e].style.width = `${sizeValue}%`
    elements[e].style.height = `${sizeValue}%`
    }
})
 */

randomiseButton.addEventListener('click', () => {
    randomiser(quantity)
})

function removeElementsByClass(className){
    let elements = document.getElementsByClassName(className);
    while(elements.length > 0){
    elements[0].parentNode.removeChild(elements[0]);
    }
}

document.addEventListener('readystatechange', function() {
    if (document.readyState === "complete") {
        moduleCreator(quantInput.value, eventSelect.value)    }
});

// <!-- screenshot -->

function makeScreenshot() {
    html2canvas(document.getElementById("screenshot"), {
    scale: 1
    }).then(canvas => {
    canvas.id = "canvasID";
    var main = document.getElementById("main");
    while (main.firstChild) {
        main.removeChild(main.firstChild);
    }
    main.appendChild(canvas);
    });
}

document.getElementById("a-make").addEventListener('click', function() {
    document.getElementById("a-make").style.display = "none";
    makeScreenshot();
    document.getElementById("a-download").style.display = "inline";
}, false);

document.getElementById("a-download").addEventListener('click', function() {
    this.href = document.getElementById("canvasID").toDataURL();
    console.log(document.getElementById("canvasID").toDataURL())
    this.download = "canvas-image.png";
}, false);